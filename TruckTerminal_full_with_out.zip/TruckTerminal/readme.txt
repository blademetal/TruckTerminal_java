When the software starts the user should click the "Vezet�s�gi bel�p�si pont" button, and then use the following username and password:
username: Admin123
pass: AdPass10

Only the admin is authorized to register a new user(in this case employee).